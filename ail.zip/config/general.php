<?php
//KONFIGURASI API AUTORESBOT
return [
    'api' => [
        'tiktok' => [
            'endpoint' => 'https://api.autoresbot.com/api/downloader/tiktok',
            'apikey' => 'db9e8e8ec71ccd462b1ab06a'
        ]
    ]
];



